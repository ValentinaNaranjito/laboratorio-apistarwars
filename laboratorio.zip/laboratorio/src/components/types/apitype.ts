export interface apitype {
    anime_name: string,
    url: string,
}